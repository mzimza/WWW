README.txt

Wykonane są pierwsze 3 punkty z zadania. (To na 3 i dwa pierwsze po 0,5).

Niestety nie zdążyłam zrobić odpowiednio dużo wyników/obiektów/instancji modeli, daltego też pozwoliłam sobie
na paginacje, co dwa wyniki, żeby pokazać, że działa.