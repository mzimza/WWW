from django.shortcuts import render
from django.contrib import messages
from django.db.models import Q
import operator
from operator import itemgetter, attrgetter
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from models import *

# Create your views here.

def index(request):

	bets = Bet.objects.all().order_by('game', 'name', 'bet_result')
	paginator = Paginator(bets, 2) # Show 2 contacts per page
	page = request.GET.get('page')
	try:
		bets = paginator.page(page)
	except PageNotAnInteger:
		bets = paginator.page(1)
	except EmptyPage:
		bets = paginator.page(paginator.num_pages)

	for p in Person.objects.all():
		point = Points.objects.get(whose=p)
		Points.add_point(point)

	points = Points.objects.all().order_by('-points')
	context = {'bets_list' : bets, 'p_list' : points}
	return render(request, 'a/x.html', context)