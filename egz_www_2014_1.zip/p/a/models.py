from django.db import models
from django.core.exceptions import ValidationError
import re

# Create your models here.

class Game(models.Model):
	description = models.CharField(max_length=150)
	result = models.CharField(max_length=3, blank=True)
	def __unicode__(self):
		return self.description
	def save(self, *args, **kwargs):
		super(Game, self).save(*args, **kwargs)

class Person(models.Model):
	name = models.CharField(max_length=30)
	# points = models.IntegerField()
	def __unicode__(self):
		return self.name
	def save(self, *args, **kwargs):
		new = Points(self, 0)
		new.save()
		super(Person, self).save(*args, **kwargs)

class Bet(models.Model):
	name = models.ForeignKey(Person, blank=False)
	game = models.ForeignKey(Game, blank=False)
	bet_result = models.CharField(max_length=3, blank=False)

	def clean(self):
		error = False
		parseError = False
		for b in Bet.objects.all():
			if (b.name == self.name) and (b.game == self.game):
				error = True
		x = re.match('[0-9]-[0-9]', self.bet_result)
		if (x == None):
			raise ValidationError('Wrong format of the bet!')
		if error:
			raise ValidationError('You can only place one bet for each game!')

class Points(models.Model):
	whose = models.OneToOneField(Person, primary_key=True)
	points = models.IntegerField()
	def __unicode__(self):
		return u'%s' % self.whose
	def add_point(self):
		self.points = 0
		for b in Bet.objects.filter(name=self.whose):
			b_f = int(b.bet_result[0])
			b_s = int(b.bet_result[2])
			game = Game.objects.get(id=b.game.id)
			if (game.result != ''):
				g_f = int(game.result[0])
				g_s = int(game.result[2])
				if (b_f == g_f) and (b_s == g_s):
					self.points = self.points + 3
				elif (b_f >= b_s) and (g_f > g_s):
					self.points = self.points + 1
				elif (b_f <= b_s) and (g_f < g_s):
					self.points = self.points + 1
		self.save()


