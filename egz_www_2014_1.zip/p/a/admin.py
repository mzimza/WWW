from django.contrib import admin
from models import *

# Register your models here.
class GameAdmin(admin.ModelAdmin):
	list_display = ('description', 'result')

class BetAdmin(admin.ModelAdmin):
	list_display = ('game', 'name', 'bet_result')

admin.site.register(Person)
admin.site.register(Game, GameAdmin)
admin.site.register(Bet, BetAdmin)