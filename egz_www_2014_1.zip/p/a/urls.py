from django.conf.urls import patterns, url
#from django.views.generic import TemplateView, ListView

from a import views

urlpatterns = patterns('',
    url(r'^$', 'a.views.index', name='index'),
)